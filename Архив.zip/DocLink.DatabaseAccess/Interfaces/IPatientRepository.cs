using DocLink.Core.Models;

namespace DocLink.Data.Interfaces;

public class IPatientRepository
{
}