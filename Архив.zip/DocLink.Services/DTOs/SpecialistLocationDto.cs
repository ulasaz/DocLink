namespace DocLink.Services.DTO_s;

public class SpecialistLocationDto
{
    public string City { get; set; }
    public string Address { get; set; }
}