namespace DocLink.Services.DTO_s;

public class ReviewDto
{
    public string AuthorName { get; set; }
    public int Rate { get; set; }
    public string Content { get; set; }
}